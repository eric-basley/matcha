module.exports = {
	postgres: {
		password: 'capucines',
	},
	optionGeocoder: {
		apiKey: 'AIzaSyC9NS3pHxPN1tr8P1bh0IlMdqfVbbe-XsA',
	},
	secretSentence: 'figaro',
	secretPasswordMail: 'funpasswordmatcha',
};
